#######################################################################
# dev : awenk audico
# EMAIL SAHIDINAOLA@GMAIL.COM
# WEBSITE WWW.TEETAH.ART
# File NAME : C:\Users\User\Desktop\FLOWORK\plugins\flowork_core_ui\template_manager_page.py
# JUMLAH BARIS : 143
#######################################################################

import ttkbootstrap as ttk
from tkinter import ttk as tk_ttk, messagebox, filedialog
import os
import shutil
import json
import platform
import subprocess
from flowork_kernel.ui_shell.custom_widgets.tooltip import ToolTip
class TemplateManagerPage(ttk.Frame):
    def __init__(self, parent_notebook, kernel_instance):
        super().__init__(parent_notebook, style='TFrame')
        self.kernel = kernel_instance
        self.loc = self.kernel.get_service("localization_manager") # [PENAMBAHAN]: Menggunakan metode get_service() yang benar.
        self.create_widgets()
        theme_manager = self.kernel.get_service("theme_manager")
        if theme_manager:
            self.apply_styles(theme_manager.get_colors()) # CHANGED: Calling get_colors() method
        self.populate_template_list()
    def apply_styles(self, colors):
        style = tk_ttk.Style(self)
        style.configure('TFrame', background=colors.get('bg'))
        style.configure('TLabel', background=colors.get('bg'), foreground=colors.get('fg'))
        style.configure('TLabelframe', background=colors.get('bg'), borderwidth=1, relief='solid', bordercolor=colors.get('border'))
        style.configure('TLabelframe.Label', background=colors.get('bg'), foreground=colors.get('fg'), font=('Helvetica', 10, 'bold'))
    def create_widgets(self):
        main_container_frame = ttk.Frame(self, padding=20, style='TFrame')
        main_container_frame.pack(fill="both", expand=True)
        theme_frame = ttk.LabelFrame(main_container_frame, text=self.loc.get('theme_management_title'), padding=15, style='TLabelframe')
        theme_frame.pack(fill="both", expand=True, pady=(0, 20))
        upload_theme_button = ttk.Button(theme_frame, text=self.loc.get('upload_theme_button'), command=self.upload_theme, style="info.TButton")
        upload_theme_button.pack(fill='x', pady=5)
        self.theme_list_frame = ttk.Frame(theme_frame, style='TFrame')
        self.theme_list_frame.pack(fill='both', expand=True, pady=(10,0))
    def populate_template_list(self):
        self.kernel.write_to_log(self.loc.get('log_populating_theme_list'), "DEBUG")
        for widget in self.theme_list_frame.winfo_children():
            widget.destroy()
        theme_manager = self.kernel.get_service("theme_manager")
        themes = theme_manager.get_all_themes() if theme_manager else {}
        if not themes:
            ttk.Label(self.theme_list_frame, text=self.loc.get('no_themes_installed_message'), style='TLabel').pack()
            self.kernel.write_to_log(self.loc.get('log_no_themes_found'), "INFO")
            return
        sorted_themes = sorted(themes.items(), key=lambda item: item[1].get('name', item[0]).lower())
        for theme_id, theme_data in sorted_themes:
            theme_name = theme_data.get('name', theme_id)
            item_frame = ttk.Frame(self.theme_list_frame, style='TFrame')
            item_frame.pack(fill='x', pady=2)
            label_text = self.loc.get('theme_list_item_format', name=theme_name, id=theme_id)
            ttk.Label(item_frame, text=label_text, style='TLabel').pack(side='left', anchor='w', fill='x', expand=True)
            buttons_frame = ttk.Frame(item_frame, style='TFrame')
            buttons_frame.pack(side='right')
            is_removable = (theme_id != "flowork_default")
            if is_removable:
                uninstall_button = ttk.Button(buttons_frame, text=self.loc.get('uninstall_button'), style="link", width=2, command=lambda tid=theme_id, tname=theme_name: self.uninstall_theme(tid, tname))
                ToolTip(uninstall_button).update_text(self.loc.get('tooltip_delete_theme'))
                uninstall_button.pack(side='right', padx=(5,0))
            edit_button = ttk.Button(buttons_frame, text=self.loc.get('edit_button'), style="info-link", width=2, command=lambda tid=theme_id: self.edit_theme(tid))
            ToolTip(edit_button).update_text(self.loc.get('tooltip_edit_theme'))
            edit_button.pack(side='right', padx=(5,0))
            self.kernel.write_to_log(self.loc.get('log_theme_added_to_list', name=theme_name, id=theme_id), "DEBUG")
        self.kernel.write_to_log(self.loc.get('log_theme_list_populated_success'), "INFO")
    def _open_path_in_explorer(self, path):
        try:
            if platform.system() == "Windows":
                os.startfile(path)
            elif platform.system() == "Darwin":
                subprocess.Popen(["open", path])
            else:
                subprocess.Popen(["xdg-open", path])
            self.kernel.write_to_log(self.loc.get('log_opening_folder', path=path), "INFO")
        except Exception as e:
            error_msg = self.loc.get('log_failed_to_open_folder', path=path, error=str(e))
            self.kernel.write_to_log(error_msg, "ERROR")
            messagebox.showerror(self.loc.get('error_title'), error_msg)
    def edit_theme(self, theme_id):
        theme_manager = self.kernel.get_service("theme_manager")
        if not theme_manager: return
        all_themes = theme_manager.get_all_themes()
        theme_data = all_themes.get(theme_id)
        if theme_data and 'path' in theme_data:
            self._open_path_in_explorer(theme_data['path'])
        else:
            messagebox.showerror(self.loc.get('error_title'), self.loc.get('theme_not_found_error', name=theme_id))
    def uninstall_theme(self, theme_id, theme_name):
        self.kernel.write_to_log(self.loc.get('log_uninstall_theme_attempt', name=theme_name, id=theme_id), "INFO")
        theme_manager = self.kernel.get_service("theme_manager")
        if not theme_manager: return
        all_themes = theme_manager.get_all_themes()
        theme_data = all_themes.get(theme_id)
        if not theme_data:
            messagebox.showerror(self.loc.get('error_title'), self.loc.get('theme_not_found_error', name=theme_name))
            self.kernel.write_to_log(self.loc.get('log_theme_not_found_for_uninstall', fallback="ERROR: Tema '{name}' ({id}) tidak ditemukan untuk di-uninstall.", name=theme_name, id=theme_id), "ERROR")
            return
        theme_path_to_delete = theme_data['path']
        if messagebox.askyesno(self.loc.get('confirm_delete_title'), self.loc.get('confirm_delete_theme_message', name=theme_name)):
            try:
                os.remove(theme_path_to_delete)
                self.kernel.write_to_log(self.loc.get('log_theme_deleted_success', name=theme_name), "SUCCESS")
                messagebox.showinfo(self.loc.get('success_title'), self.loc.get('theme_deleted_success_message', name=theme_name))
                self.populate_template_list() # Refresh UI
                self.kernel.root.refresh_ui_components()
            except Exception as e:
                error_msg = self.loc.get('theme_delete_failed_error', name=theme_name, error=e)
                self.kernel.write_to_log(error_msg, "ERROR")
                messagebox.showerror(self.loc.get('failed_title'), error_msg)
        else:
            self.kernel.write_to_log(self.loc.get('log_theme_uninstall_cancelled', name=theme_name), "INFO")
    def upload_theme(self):
        self.kernel.write_to_log(self.loc.get('log_upload_theme_started'), "INFO")
        filepath = filedialog.askopenfilename(
            title=self.loc.get('select_theme_file_title'),
            filetypes=[(self.loc.get('json_files_label'), "*.json")]
        )
        if not filepath:
            self.kernel.write_to_log(self.loc.get('theme_upload_cancelled'), "WARN")
            return
        theme_manager = self.kernel.get_service("theme_manager")
        if not theme_manager: return
        try:
            with open(filepath, 'r', encoding='utf-8') as f:
                theme_data = json.load(f)
                if "name" not in theme_data or "colors" not in theme_data:
                    raise ValueError(self.loc.get('invalid_theme_format_error'))
            theme_filename = os.path.basename(filepath)
            target_path = os.path.join(self.kernel.themes_path, theme_filename)
            shutil.copyfile(filepath, target_path)
            success_msg = self.loc.get('theme_upload_success', name=theme_data['name'])
            messagebox.showinfo(self.loc.get('success_title'), success_msg)
            self.populate_template_list() # Refresh UI
            self.kernel.root.refresh_ui_components()
        except Exception as e:
            error_msg_detail = str(e)
            error_msg_localized = self.loc.get('theme_upload_failed_error', filename=os.path.basename(filepath), error=error_msg_detail)
            self.kernel.write_to_log(error_msg_localized, "ERROR")
            messagebox.showerror(self.loc.get('theme_upload_failed_title'), error_msg_localized)
