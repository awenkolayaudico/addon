#######################################################################
# dev : awenk audico
# EMAIL SAHIDINAOLA@GMAIL.COM
# WEBSITE WWW.TEETAH.ART
# File NAME : C:\Users\User\Desktop\FLOWORK\plugins\flowork_core_ui\ai_architect_page.py
# JUMLAH BARIS : 84
#######################################################################

import ttkbootstrap as ttk
from tkinter import scrolledtext, messagebox
import threading
class AiArchitectPage(ttk.Frame):
    """
    The user interface for the AI Architect feature, allowing users to generate
    workflows from natural language prompts.
    """
    def __init__(self, parent_notebook, kernel_instance):
        super().__init__(parent_notebook, padding=20)
        self.kernel = kernel_instance
        self.loc = self.kernel.get_service("localization_manager")
        self._build_ui()
    def _build_ui(self):
        """Builds the main widgets for the page."""
        self.columnconfigure(0, weight=1)
        self.rowconfigure(1, weight=1)
        header_frame = ttk.Frame(self)
        header_frame.grid(row=0, column=0, sticky="ew", pady=(0, 10))
        ttk.Label(header_frame, text="AI Architect", font=("Helvetica", 16, "bold")).pack(side="left", anchor="w")
        self.status_label = ttk.Label(header_frame, text="Ready.", bootstyle="secondary")
        self.status_label.pack(side="right", anchor="e")
        self.prompt_text = scrolledtext.ScrolledText(self, wrap="word", height=10, font=("Helvetica", 11))
        self.prompt_text.grid(row=1, column=0, sticky="nsew")
        self.prompt_text.insert("1.0", "Contoh: Buatkan alur kerja yang mengambil data dari web scraper lalu menampilkannya di popup debug.")
        button_container = ttk.Frame(self)
        button_container.grid(row=2, column=0, sticky="ew", pady=(10, 0))
        button_container.columnconfigure(0, weight=1)
        self.generate_button = ttk.Button(button_container, text="🚀 Generate Workflow", command=self._start_generation_thread, bootstyle="success")
        self.generate_button.grid(row=0, column=0, sticky="ew", ipady=5)
    def _start_generation_thread(self):
        """
        Starts the workflow generation in a background thread to keep the UI responsive.
        """
        user_prompt = self.prompt_text.get("1.0", "end-1c").strip()
        if not user_prompt:
            messagebox.showwarning("Prompt Kosong", "Tolong tuliskan alur kerja seperti apa yang kamu inginkan.")
            return
        self.generate_button.config(state="disabled")
        self.status_label.config(text="Berpikir...", bootstyle="info")
        thread = threading.Thread(target=self._generate_workflow_worker, args=(user_prompt,), daemon=True)
        thread.start()
    def _generate_workflow_worker(self, user_prompt):
        """
        The actual worker function that calls the AI Architect service.
        """
        try:
            architect_service = self.kernel.get_service("ai_architect_service")
            if not architect_service:
                raise RuntimeError("AiArchitectService not available.")
            workflow_json = architect_service.generate_workflow_from_prompt(user_prompt)
            self.after(0, self._on_generation_complete, True, workflow_json, user_prompt)
        except Exception as e:
            self.after(0, self._on_generation_complete, False, str(e), None)
    def _on_generation_complete(self, success, result, user_prompt):
        """
        Callback executed on the main UI thread after the AI finishes processing.
        """
        self.generate_button.config(state="normal")
        if success:
            self.status_label.config(text="Sukses! Tab baru dibuat.", bootstyle="success")
            tab_manager = self.kernel.get_service("tab_manager_service")
            new_tab = tab_manager.add_new_workflow_tab()
            self.after(100, lambda: self._populate_new_tab(new_tab, result, user_prompt))
        else:
            self.status_label.config(text="Gagal.", bootstyle="danger")
            messagebox.showerror("AI Architect Error", f"Gagal membuat alur kerja:\n\n{result}")
    def _populate_new_tab(self, new_tab_frame, workflow_json, user_prompt):
        """
        Loads the generated workflow data into the newly created tab.
        """
        if hasattr(new_tab_frame, 'canvas_area_instance') and new_tab_frame.canvas_area_instance:
            new_tab_frame.canvas_area_instance.canvas_manager.load_workflow_data(workflow_json)
            tab_title = user_prompt[:25] + '...' if len(user_prompt) > 25 else user_prompt
            self.kernel.get_service("tab_manager_service").notebook.tab(new_tab_frame, text=f" {tab_title} ")
        else:
            self.after(200, lambda: self._populate_new_tab(new_tab_frame, workflow_json, user_prompt))
