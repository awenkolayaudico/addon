#######################################################################
# dev : awenk audico
# EMAIL SAHIDINAOLA@GMAIL.COM
# WEBSITE WWW.TEETAH.ART
# File NAME : C:\Users\User\Desktop\FLOWORK\plugins\flowork_core_ui\settings_components\ai_provider_settings_frame.py
# JUMLAH BARIS : 58
#######################################################################

import ttkbootstrap as ttk
from tkinter import StringVar
class AiProviderSettingsFrame(ttk.LabelFrame):
    """
    A frame to display and manage AI Provider settings.
    [REFACTORED] Now reports its settings to a parent coordinator.
    """
    def __init__(self, parent, kernel):
        self.kernel = kernel
        self.loc = self.kernel.get_service("localization_manager")
        super().__init__(parent, text="Konfigurasi AI Center", padding=15)
        self.master_provider_var = StringVar()
        self.provider_display_to_id_map = {}
        self._build_widgets()
    def _build_widgets(self):
        """Builds the UI components for this frame."""
        self.columnconfigure(1, weight=1)
        label = ttk.Label(self, text="Master AI (Untuk Klasifikasi):")
        label.grid(row=0, column=0, padx=(0, 10), pady=5, sticky="w")
        self.provider_combo = ttk.Combobox(self, textvariable=self.master_provider_var, state="readonly")
        self.provider_combo.grid(row=0, column=1, padx=5, pady=5, sticky="ew")
        help_text = ttk.Label(self, text="Pilih AI yang akan bertugas menganalisa prompt awal di AI Center.", wraplength=400, justify="left", bootstyle="secondary")
        help_text.grid(row=1, column=0, columnspan=2, padx=5, pady=(5,0), sticky="w")
    def load_settings_data(self, settings_data):
        """Loads the list of providers and sets the current master provider setting."""
        ai_manager = self.kernel.get_service("ai_provider_manager_service")
        if not ai_manager:
            self.provider_combo['values'] = ["AI Manager Service not found"]
            return
        all_providers = ai_manager.get_available_providers()
        self.provider_display_to_id_map.clear()
        display_names = []
        for provider_id, display_name in all_providers.items():
            self.provider_display_to_id_map[display_name] = provider_id
            display_names.append(display_name)
        self.provider_combo['values'] = sorted(display_names)
        saved_provider_id = settings_data.get("ai_center_master_provider")
        if saved_provider_id:
            for display, pid in self.provider_display_to_id_map.items():
                if pid == saved_provider_id:
                    self.master_provider_var.set(display)
                    return
        if display_names:
            self.master_provider_var.set(sorted(display_names)[0])
    def get_settings_data(self):
        """Returns the selected master AI provider setting."""
        selected_display_name = self.master_provider_var.get()
        if selected_display_name in self.provider_display_to_id_map:
            provider_id_to_save = self.provider_display_to_id_map[selected_display_name]
            return {"ai_center_master_provider": provider_id_to_save}
        return {}
