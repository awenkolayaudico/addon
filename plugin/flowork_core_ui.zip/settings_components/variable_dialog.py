#######################################################################
# dev : awenk audico
# EMAIL SAHIDINAOLA@GMAIL.COM
# WEBSITE WWW.TEETAH.ART
# File NAME : C:\Users\User\Desktop\FLOWORK\plugins\flowork_core_ui\settings_components\variable_dialog.py
# JUMLAH BARIS : 66
#######################################################################

import ttkbootstrap as ttk
from tkinter import StringVar, BooleanVar, messagebox
class VariableDialog(ttk.Toplevel):
    def __init__(self, parent, title, kernel, existing_name=None, is_editing_secret=False):
        super().__init__(parent)
        self.title(title)
        self.transient(parent)
        self.grab_set()
        self.loc = kernel.get_service("localization_manager")
        self.result = None
        self.name_var = StringVar(value=existing_name or "")
        self.value_var = StringVar()
        self.is_secret_var = BooleanVar(value=is_editing_secret)
        main_frame = ttk.Frame(self, padding=20)
        main_frame.pack(fill="both", expand=True)
        name_label = ttk.Label(main_frame, text=self.loc.get("settings_variables_dialog_name", fallback="Name:"))
        name_label.grid(row=0, column=0, padx=5, pady=5, sticky="w")
        self.name_entry = ttk.Entry(main_frame, textvariable=self.name_var, width=40)
        self.name_entry.grid(row=0, column=1, padx=5, pady=5, sticky="ew")
        if existing_name:
            self.name_entry.config(state="readonly")
        value_label = ttk.Label(main_frame, text=self.loc.get("settings_variables_dialog_value", fallback="Value:"))
        value_label.grid(row=1, column=0, padx=5, pady=5, sticky="w")
        self.value_entry = ttk.Entry(main_frame, textvariable=self.value_var, width=40)
        self.value_entry.grid(row=1, column=1, padx=5, pady=5, sticky="ew")
        if is_editing_secret:
            self.value_entry.config(show="*")
            self.value_entry.insert(0, self.loc.get("settings_variables_dialog_secret_placeholder", fallback="(Leave empty if you don't want to change)"))
        secret_check = ttk.Checkbutton(main_frame, text=self.loc.get("settings_variables_dialog_secret_check", fallback="Mask this value (secret)"), variable=self.is_secret_var, command=self._toggle_secret)
        secret_check.grid(row=2, column=1, padx=5, pady=10, sticky="w")
        if existing_name:
            secret_check.config(state="disabled")
        button_frame = ttk.Frame(main_frame)
        button_frame.grid(row=3, column=0, columnspan=2, pady=(10,0))
        ok_button = ttk.Button(button_frame, text=self.loc.get("button_save", fallback="Save"), command=self._on_ok, bootstyle="success")
        ok_button.pack(side="right", padx=5)
        cancel_button = ttk.Button(button_frame, text=self.loc.get("button_cancel", fallback="Cancel"), command=self.destroy, bootstyle="secondary")
        cancel_button.pack(side="right")
        self.wait_window(self)
    def _toggle_secret(self):
        if self.is_secret_var.get():
            self.value_entry.config(show="*")
        else:
            self.value_entry.config(show="")
    def _on_ok(self):
        name = self.name_var.get().strip().upper()
        value = self.value_var.get()
        is_secret = self.is_secret_var.get()
        if not name:
            messagebox.showerror(self.loc.get("messagebox_error_title", fallback="Error"), self.loc.get("settings_variables_warn_name_empty", fallback="Name cannot be empty."), parent=self)
            return
        if not name.replace('_', '').isalnum():
            messagebox.showerror(self.loc.get("messagebox_error_title", fallback="Error"), self.loc.get("settings_variables_warn_name_format"), parent=self)
            return
        if value == "" or (self.name_entry.cget('state') == 'readonly' and value == self.loc.get("settings_variables_dialog_secret_placeholder", fallback="(Leave empty if you don't want to change)")):
             messagebox.showerror(self.loc.get("messagebox_error_title", fallback="Error"), self.loc.get("settings_variables_warn_value_empty", fallback="Value cannot be empty."), parent=self)
             return
        self.result = (name, value, is_secret)
        self.destroy()
