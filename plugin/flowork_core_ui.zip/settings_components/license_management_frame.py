#######################################################################
# dev : awenk audico
# EMAIL SAHIDINAOLA@GMAIL.COM
# WEBSITE WWW.TEETAH.ART
# File NAME : C:\Users\User\Desktop\FLOWORK\plugins\flowork_core_ui\settings_components\license_management_frame.py
# JUMLAH BARIS : 62
#######################################################################

import ttkbootstrap as ttk
from tkinter import messagebox
import os
class LicenseManagementFrame(ttk.LabelFrame):
    def __init__(self, parent, kernel):
        self.kernel = kernel
        self.loc = self.kernel.get_service("localization_manager")
        super().__init__(parent, text=self.loc.get("settings_license_title", fallback="License Management"), padding=15)
        self._build_widgets()
        self.load_settings_data(None) # Panggil untuk set state awal
    def _build_widgets(self):
        self.deactivate_button = ttk.Button(
            self,
            text=self.loc.get("settings_license_deactivate_button", fallback="Deactivate License on This Computer"),
            command=self._deactivate_license,
            bootstyle="danger-outline"
        )
        self.deactivate_button.pack(pady=5, padx=5, fill='x')
    def update_ui_based_on_license_status(self):
        """Enables or disables the deactivate button based on the license status."""
        if hasattr(self, 'deactivate_button') and self.deactivate_button.winfo_exists():
            if self.kernel.is_premium_user():
                self.deactivate_button.config(state="normal")
            else:
                self.deactivate_button.config(state="disabled")
    def _deactivate_license(self):
        """Prompts for confirmation and runs the license deactivation process."""
        if messagebox.askyesno(
            self.loc.get("settings_license_deactivate_confirm_title", fallback="Confirm Deactivation"),
            self.loc.get("settings_license_deactivate_confirm_message"),
            parent=self
        ):
            success, message = self.kernel.deactivate_license_online()
            if success:
                try:
                    license_file_path = os.path.join(self.kernel.data_path, "license.seal")
                    if os.path.exists(license_file_path):
                        os.remove(license_file_path)
                    self.kernel.license_tier = "free"
                    self.kernel.is_premium = False
                    messagebox.showinfo(
                        self.loc.get("messagebox_success_title", fallback="Success"),
                        f"{message}\n\nPlease restart the application to apply all changes."
                    )
                    self.update_ui_based_on_license_status()
                except Exception as e:
                    messagebox.showerror(self.loc.get("messagebox_error_title", fallback="Error"), f"Failed to remove local license file: {e}")
            else:
                messagebox.showerror(self.loc.get("messagebox_error_title", fallback="Failed"), message, parent=self)
    def load_settings_data(self, settings_data):
        """This frame's UI is updated based on kernel state, not settings data."""
        self.update_ui_based_on_license_status()
    def get_settings_data(self):
        """This frame doesn't save any settings, it only performs actions."""
        return {}
