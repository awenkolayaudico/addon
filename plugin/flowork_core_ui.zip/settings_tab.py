#######################################################################
# dev : awenk audico
# EMAIL SAHIDINAOLA@GMAIL.COM
# WEBSITE WWW.TEETAH.ART
# File NAME : C:\Users\User\Desktop\FLOWORK\plugins\flowork_core_ui\settings_tab.py
# JUMLAH BARIS : 113
#######################################################################

import ttkbootstrap as ttk
from tkinter import messagebox
from flowork_kernel.api_client import ApiClient
from .settings_components.general_settings_frame import GeneralSettingsFrame
from .settings_components.webhook_settings_frame import WebhookSettingsFrame
from .settings_components.notification_settings_frame import NotificationSettingsFrame
from .settings_components.license_management_frame import LicenseManagementFrame
from .settings_components.error_handler_frame import ErrorHandlerFrame
from .settings_components.variable_manager_frame import VariableManagerFrame
from .settings_components.ai_provider_settings_frame import AiProviderSettingsFrame
import threading
class SettingsTab(ttk.Frame):
    """
    Acts as a container and coordinator for all the individual settings frames.
    [REFACTORED] Now fetches all settings from the API and orchestrates saving.
    """
    def __init__(self, parent_notebook, kernel_instance):
        super().__init__(parent_notebook, padding=15)
        self.kernel = kernel_instance
        self.loc = self.kernel.get_service("localization_manager")
        self.api_client = ApiClient(kernel=self.kernel) # [MODIFICATION] Pass the kernel instance
        self.all_settings_frames = []
        self._content_initialized = False
        ttk.Label(self, text="Loading Settings...").pack(expand=True)
    def _initialize_content(self):
        if self._content_initialized:
            return
        for widget in self.winfo_children():
            widget.destroy()
        self._build_ui()
        self._load_all_settings_from_api()
        self._content_initialized = True
    def _build_ui(self):
        paned_window = ttk.PanedWindow(self, orient='horizontal')
        paned_window.pack(fill='both', expand=True)
        left_frame = ttk.Frame(paned_window, padding=5)
        paned_window.add(left_frame, weight=1)
        right_frame = ttk.Frame(paned_window, padding=5)
        paned_window.add(right_frame, weight=1)
        self._build_left_panel(left_frame)
        self._build_right_panel(right_frame)
    def _build_left_panel(self, parent_frame):
        self.general_frame = GeneralSettingsFrame(parent_frame, self.kernel)
        self.general_frame.pack(fill="x", pady=5, padx=5)
        self.all_settings_frames.append(self.general_frame)
        self.ai_provider_frame = AiProviderSettingsFrame(parent_frame, self.kernel)
        self.ai_provider_frame.pack(fill="x", pady=5, padx=5)
        self.all_settings_frames.append(self.ai_provider_frame)
        self.webhook_frame = WebhookSettingsFrame(parent_frame, self.kernel)
        self.webhook_frame.pack(fill="x", pady=5, padx=5)
        self.all_settings_frames.append(self.webhook_frame)
        self.notification_frame = NotificationSettingsFrame(parent_frame, self.kernel)
        self.notification_frame.pack(fill="x", pady=5, padx=5)
        self.all_settings_frames.append(self.notification_frame)
        self.license_frame = LicenseManagementFrame(parent_frame, self.kernel)
        self.license_frame.pack(fill="x", pady=5, padx=5)
        self.all_settings_frames.append(self.license_frame) # Added license frame to the list
        self.error_handler_frame = ErrorHandlerFrame(parent_frame, self.kernel)
        self.error_handler_frame.pack(fill="x", pady=5, padx=5, expand=True, anchor="n")
        self.all_settings_frames.append(self.error_handler_frame)
        save_button = ttk.Button(parent_frame, text=self.loc.get("settings_save_button", fallback="Save All Settings"), command=self._save_all_settings, bootstyle="success")
        save_button.pack(pady=20, padx=5, side="bottom", anchor="e")
    def _build_right_panel(self, parent_frame):
        self.variable_manager_frame = VariableManagerFrame(parent_frame, self.kernel)
        self.variable_manager_frame.pack(fill="both", expand=True, pady=5, padx=5)
    def _load_all_settings_from_api(self):
        """[MODIFICATION] Fetches settings in a background thread."""
        threading.Thread(target=self._load_settings_worker, daemon=True).start()
    def _load_settings_worker(self):
        """[ADDED] Worker thread to get settings from the API."""
        success, settings_data = self.api_client.get_all_settings()
        self.after(0, self._populate_settings_ui, success, settings_data)
    def _populate_settings_ui(self, success, settings_data):
        """[ADDED] Callback to safely update the UI with settings data."""
        if success:
            for frame in self.all_settings_frames:
                if hasattr(frame, 'load_settings_data'):
                    frame.load_settings_data(settings_data)
        else:
            messagebox.showerror(self.loc.get("messagebox_error_title"), f"Failed to load settings from API: {settings_data}")
    def _save_all_settings(self):
        """
        [MODIFICATION] Gathers and saves settings in a background thread.
        """
        all_new_settings = {}
        try:
            for frame in self.all_settings_frames:
                if hasattr(frame, 'get_settings_data'):
                    all_new_settings.update(frame.get_settings_data())
            threading.Thread(target=self._save_settings_worker, args=(all_new_settings,), daemon=True).start()
        except ValueError as e:
            messagebox.showerror(self.loc.get("messagebox_error_title"), str(e))
        except Exception as e:
            messagebox.showerror(self.loc.get("messagebox_error_title"), f"{self.loc.get('settings_save_error_msg')}: {e}")
    def _save_settings_worker(self, settings_to_save):
        """[ADDED] Worker thread to save settings via the API."""
        success, response = self.api_client.save_settings(settings_to_save)
        self.after(0, self._on_save_settings_complete, success, response)
    def _on_save_settings_complete(self, success, response):
        """[ADDED] Callback to show result after saving."""
        if success:
            messagebox.showinfo(self.loc.get("messagebox_success_title"), self.loc.get("settings_save_success_msg"))
            self._load_all_settings_from_api() # Reload settings after saving
            self.kernel.root.refresh_ui_components()
        else:
             messagebox.showerror(self.loc.get("messagebox_error_title"), f"API Error: {response}")
