#######################################################################
# dev : awenk audico
# EMAIL SAHIDINAOLA@GMAIL.COM
# WEBSITE WWW.TEETAH.ART
# File NAME : C:\Users\User\Desktop\FLOWORK\plugins\flowork_core_ui\ore_editor_page.py
# JUMLAH BARIS : 24
#######################################################################

import ttkbootstrap as ttk
class CoreEditorPage(ttk.Frame):
    """
    The placeholder UI for the "Meta-Developer Mode" where core service
    workflows (.flowork files) can be visually edited.
    """
    def __init__(self, parent_notebook, kernel_instance):
        super().__init__(parent_notebook, padding=20)
        self.kernel = kernel_instance
        self.loc = self.kernel.get_service("localization_manager")
        label = ttk.Label(
            self,
            text="Core Workflow Editor - Coming Soon!",
            font=("Helvetica", 16, "bold"),
            bootstyle="info"
        )
        label.pack(expand=True)
