#######################################################################
# dev : awenk audico
# EMAIL SAHIDINAOLA@GMAIL.COM
# WEBSITE WWW.TEETAH.ART
# File NAME : C:\Users\User\Desktop\FLOWORK\plugins\flowork_core_ui\pricing_page.py
# JUMLAH BARIS : 111
#######################################################################

import ttkbootstrap as ttk
import webbrowser
class PricingPage(ttk.Frame):
    """
    A UI frame that displays the different license tiers and their features,
    with dynamic buttons based on the user's current license.
    """
    def __init__(self, parent_notebook, kernel_instance):
        super().__init__(parent_notebook, padding=20)
        self.kernel = kernel_instance
        self.loc = self.kernel.get_service("localization_manager")
        self.master_feature_list = [
            "feature_visual_editor", "feature_basic_modules", "feature_manual_install",
            "feature_headless_mode", "feature_theme_customization", "feature_limited_api",
            "feature_unlimited_api", "feature_time_travel_debugger", "feature_preset_versioning",
            "feature_basic_tier_addons", "feature_pro_tier_addons", "feature_marketplace_upload",
            "feature_ai_copilot", "feature_advanced_triggers", "feature_architect_tier_addons",
            "feature_ai_architect", "feature_core_editor", "feature_enterprise_tier_addons",
            "feature_advanced_security", "feature_priority_support", "feature_team_collaboration"
        ]
        self.upgrade_urls = {
            "basic": "https://www.teetah.art/pricing/basic",
            "pro": "https://www.teetah.art/pricing/pro",
            "architect": "https://www.teetah.art/pricing/architect",
            "enterprise": "https://contact.teetah.art"
        }
        self._build_ui()
    def _build_ui(self):
        """Builds the main widgets for the page."""
        container = ttk.Frame(self)
        container.pack(fill='both', expand=True)
        self.tier_data = {
            "free": {
                "title_key": "tier_free_title", "price_key": "tier_free_price", "desc_key": "tier_free_desc",
                "style": "secondary",
                "features": [ "feature_visual_editor", "feature_basic_modules", "feature_manual_install", "feature_limited_api", "feature_headless_mode", "feature_theme_customization" ]
            },
            "basic": {
                "title_key": "tier_basic_title", "price_key": "tier_basic_price", "desc_key": "tier_basic_desc",
                "style": "info",
                "features": [ "feature_unlimited_api", "feature_time_travel_debugger", "feature_preset_versioning", "feature_basic_tier_addons" ]
            },
            "pro": {
                "title_key": "tier_pro_title", "price_key": "tier_pro_price", "desc_key": "tier_pro_desc",
                "style": "success",
                "features": [ "feature_pro_tier_addons", "feature_marketplace_upload", "feature_ai_copilot", "feature_advanced_triggers" ]
            },
            "architect": {
                "title_key": "tier_architect_title", "price_key": "tier_architect_price", "desc_key": "tier_architect_desc",
                "style": "primary",
                "features": [ "feature_architect_tier_addons", "feature_ai_architect", "feature_core_editor" ]
            },
            "enterprise": {
                "title_key": "tier_enterprise_title", "price_key": "tier_enterprise_price", "desc_key": "tier_enterprise_desc",
                "style": "dark",
                "features": [ "feature_enterprise_tier_addons", "feature_advanced_security", "feature_priority_support", "feature_team_collaboration" ]
            }
        }
        for i, (tier_key, data) in enumerate(self.tier_data.items()):
            container.columnconfigure(i, weight=1)
            self._create_tier_card(container, tier_key, data).grid(row=0, column=i, sticky="nsew", padx=10)
    def _create_tier_card(self, parent, tier_key, data):
        """Helper function to create a single tier card."""
        title = self.loc.get(data['title_key'])
        card = ttk.LabelFrame(parent, text=title, padding=15, bootstyle=data['style'])
        price_text = self.loc.get(data['price_key'])
        ttk.Label(card, text=price_text, font="-weight bold -size 12").pack(fill='x', pady=(0, 5))
        desc_text = self.loc.get(data['desc_key'])
        ttk.Label(card, text=desc_text, wraplength=200, justify='center', anchor='center').pack(fill='x', pady=(0, 15))
        features_frame = ttk.Frame(card)
        features_frame.pack(fill='x', expand=False, pady=(0, 20))
        features_in_this_tier = []
        for tier, tier_info in self.kernel.TIER_HIERARCHY.items():
            if tier_info <= self.kernel.TIER_HIERARCHY[tier_key]:
                if tier in self.tier_data:
                    features_in_this_tier.extend(self.tier_data.get(tier, {}).get('features', []))
        features_in_this_tier = set(features_in_this_tier)
        for feature_key in self.master_feature_list:
            feature_text = self.loc.get(feature_key, fallback=feature_key.replace('_', ' ').title())
            if feature_key in features_in_this_tier:
                ttk.Label(features_frame, text=f"✓ {feature_text}", anchor='w').pack(fill='x')
            else:
                ttk.Label(features_frame, text=f"– {feature_text}", anchor='w', bootstyle="secondary").pack(fill='x')
        ttk.Frame(card).pack(fill='y', expand=True)
        user_tier_level = self.kernel.TIER_HIERARCHY[self.kernel.license_tier]
        card_tier_level = self.kernel.TIER_HIERARCHY[tier_key]
        btn_command = None # Default command
        if user_tier_level == card_tier_level:
            btn_text = self.loc.get('btn_current_plan')
            btn_state = "disabled"
        elif user_tier_level > card_tier_level:
            btn_text = self.loc.get('btn_included')
            btn_state = "disabled"
        elif tier_key == "enterprise":
            btn_text = self.loc.get('btn_contact_us')
            btn_state = "normal"
            btn_command = lambda: webbrowser.open(self.upgrade_urls['enterprise'])
        else:
            btn_text = self.loc.get('btn_upgrade')
            btn_state = "normal"
            btn_command = lambda url=self.upgrade_urls[tier_key]: webbrowser.open(url)
        action_button = ttk.Button(card, text=btn_text, state=btn_state, command=btn_command, bootstyle=f"{data['style']}")
        action_button.pack(fill='x', ipady=5)
        return card
