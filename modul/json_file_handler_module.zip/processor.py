#######################################################################
# dev : awenk audico
# EMAIL SAHIDINAOLA@GMAIL.COM
# WEBSITE WWW.TEETAH.ART
# File NAME : C:\Users\User\Desktop\FLOWORK\modules\json_file_handler_module\processor.py
# JUMLAH BARIS : 56
#######################################################################

import os
import json
from flowork_kernel.api_contract import BaseModule
from flowork_kernel.utils.payload_helper import get_nested_value
class JsonFileHandlerModule(BaseModule):
    TIER = "free"  # ADDED BY SCANNER: Default tier
    def execute(self, payload, config, status_updater, ui_callback, mode='EXECUTE'):
        operation = config.get('operation', 'read')
        file_path_source_var = config.get('source_variable')
        if file_path_source_var:
            file_path = get_nested_value(payload, file_path_source_var)
            self.logger(f"JSON Handler got dynamic path '{file_path}' from payload variable '{file_path_source_var}'", "DEBUG")
        else:
            file_path = config.get('file_path')
            self.logger(f"JSON Handler using static path: '{file_path}'", "DEBUG")
        if not file_path:
            error_msg = "File path is not specified or could not be found in payload."
            self.logger(error_msg, "ERROR")
            payload['error'] = error_msg
            return {"payload": payload, "output_name": "error"}
        try:
            if operation == 'read':
                status_updater(f"Reading JSON from {file_path}...", "INFO")
                if not os.path.exists(file_path):
                    raise FileNotFoundError(f"File not found: {file_path}")
                with open(file_path, 'r', encoding='utf-8') as f:
                    json_data = json.load(f)
                if 'data' not in payload or not isinstance(payload['data'], dict):
                    payload['data'] = {}
                payload['data']['json_content'] = json_data
                status_updater("Read successful.", "SUCCESS")
            elif operation == 'write':
                status_updater(f"Writing JSON to {file_path}...", "INFO")
                data_var = config.get('data_variable_to_write')
                if not data_var:
                    raise ValueError("Data variable to write is not specified.")
                data_to_write = get_nested_value(payload, data_var)
                if data_to_write is None:
                    raise ValueError(f"Could not find data in payload at '{data_var}'.")
                with open(file_path, 'w', encoding='utf-8') as f:
                    json.dump(data_to_write, f, indent=4)
                status_updater("Write successful.", "SUCCESS")
            return {"payload": payload, "output_name": "success"}
        except Exception as e:
            self.logger(f"JSON Handler error on '{file_path}': {e}", "ERROR")
            payload['error'] = str(e)
            return {"payload": payload, "output_name": "error"}
    def create_properties_ui(self, parent_frame, get_current_config, available_vars):
        pass
