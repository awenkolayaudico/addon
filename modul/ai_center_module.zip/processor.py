#######################################################################
# dev : awenk audico
# EMAIL SAHIDINAOLA@GMAIL.COM
# WEBSITE WWW.TEETAH.ART
# File NAME : C:\Users\User\Desktop\FLOWORK\modules\ai_center_module\processor.py
# JUMLAH BARIS : 164
#######################################################################

import ttkbootstrap as ttk
from tkinter import StringVar
from flowork_kernel.api_contract import BaseModule, IExecutable, IConfigurableUI
from flowork_kernel.ui_shell import shared_properties
from flowork_kernel.ui_shell.components.LabelledCombobox import LabelledCombobox
from flowork_kernel.ui_shell.components.InfoLabel import InfoLabel
from flowork_kernel.utils.payload_helper import get_nested_value
from flowork_kernel.api_contract import IDataPreviewer
class AICenterModule(BaseModule, IExecutable, IConfigurableUI, IDataPreviewer):
    TIER = "free"  # ADDED BY SCANNER: Default tier
    TASK_CATEGORIES = [
        "TEXT_GENERATION", "IMAGE_GENERATION", "AUDIO_GENERATION",
        "VIDEO_GENERATION", "CODE_GENERATION", "DATA_ANALYSIS"
    ]
    def execute(self, payload, config, status_updater, ui_callback, mode='EXECUTE'):
        prompt = ""
        prompt_source_variable = config.get('prompt_source_variable')
        if prompt_source_variable:
            prompt = get_nested_value(payload, prompt_source_variable)
            self.logger(f"AI Center got prompt from dynamic variable: '{prompt_source_variable}'", "DEBUG")
        if not prompt:
            payload_data = payload.get('data', {})
            if isinstance(payload_data, dict):
                possible_keys = ['prompt', 'konten', 'message', 'text', 'data']
                for key in possible_keys:
                    if key in payload_data and payload_data[key]:
                        prompt = payload_data[key]
                        break
            elif isinstance(payload_data, str):
                prompt = payload_data
        if not prompt:
            raise ValueError("Could not find a valid prompt in the payload.")
        status_updater("Analyzing prompt intent...", "INFO")
        task_category = None
        prompt_lower = prompt.lower()
        keyword_map = {
            "AUDIO_GENERATION": ["musik", "lagu", "sound", "audio", "aransemen"],
            "IMAGE_GENERATION": ["gambar", "lukisan", "image", "foto", "ilustrasi", "logo"],
            "VIDEO_GENERATION": ["video", "film", "klip", "animasi"],
            "CODE_GENERATION": ["kode", "script", "program", "function", "fungsi", "class"],
            "DATA_ANALYSIS": ["analisa", "data", "csv", "json", "laporan", "statistik"]
        }
        for category, keywords in keyword_map.items():
            if any(keyword in prompt_lower for keyword in keywords):
                task_category = category
                self.logger(f"Keyword match found. Classifying as: {task_category}", "INFO")
                break
        if not task_category:
            self.logger("No keyword match. Using master AI for classification.", "INFO")
            master_provider = self.kernel.ai_manager.get_default_provider()
            if not master_provider:
                raise ConnectionError("No default AI Provider is set to act as the Master Router.")
            provider_mapping = config.get('provider_mapping', {})
            task_categories_for_prompt = list(provider_mapping.keys())
            classification_prompt = self.loc.get(
                'ai_center_classification_prompt_advanced',
                fallback="Classify: '{prompt}' into one of {categories}",
                categories=task_categories_for_prompt,
                prompt=prompt
            )
            classification_result = master_provider.generate_response(classification_prompt)
            task_category_from_ai = classification_result.get('data', '').strip().upper().replace(" ", "_")
            if task_category_from_ai in self.TASK_CATEGORIES:
                task_category = task_category_from_ai
            else:
                self.logger(f"Master AI failed to classify or returned unknown category: '{task_category_from_ai}'. Using TEXT_GENERATION as fallback.", "WARN")
                task_category = "TEXT_GENERATION"
        status_updater(f"Task classified as: {task_category}", "INFO")
        provider_mapping = config.get('provider_mapping', {})
        target_provider_id = provider_mapping.get(task_category)
        if not target_provider_id:
            raise ValueError(f"No AI provider is configured for the task category '{task_category}'.")
        specialized_provider = self.kernel.ai_manager.get_provider(target_provider_id)
        if not specialized_provider:
            raise ConnectionError(f"Configured provider '{target_provider_id}' for '{task_category}' could not be found.")
        status_updater(f"Delegating to {specialized_provider.get_provider_name()}...", "INFO")
        result = specialized_provider.generate_response(prompt)
        result_type = result.get('type', 'text').lower()
        result_data = result.get('data')
        if 'data' not in payload or not isinstance(payload.get('data'), dict):
             payload['data'] = {}
        payload['data'][f'ai_result_{result_type}'] = result_data
        payload['data']['prompt'] = prompt
        output_port_map = {
            'text': 'text_output',
            'image_url': 'image_output',
            'audio_file': 'audio_output',
            'video_url': 'video_output',
            'code': 'code_output',
            'json': 'data_output'
        }
        output_name = output_port_map.get(result_type, 'default_output')
        status_updater("Task completed!", "SUCCESS")
        return {"payload": payload, "output_name": output_name}
    def create_properties_ui(self, parent_frame, get_current_config, available_vars):
        config = get_current_config()
        property_vars = {}
        prompt_source_frame = ttk.LabelFrame(parent_frame, text="Sumber Prompt")
        prompt_source_frame.pack(fill='x', padx=5, pady=10)
        if not available_vars or all(k in ['data', 'history'] for k in available_vars.keys()):
            InfoLabel(parent=prompt_source_frame, text="Hubungkan node sebelumnya untuk mendeteksi variabel output secara otomatis.")
        else:
            property_vars['prompt_source_variable'] = StringVar(value=config.get('prompt_source_variable', ''))
            LabelledCombobox(
                parent=prompt_source_frame,
                label_text="Gunakan Output dari:",
                variable=property_vars['prompt_source_variable'],
                values=list(available_vars.keys())
            )
        category_vars = {}
        main_frame = ttk.LabelFrame(parent_frame, text="AI Center Control Cockpit")
        main_frame.pack(fill='x', padx=5, pady=10)
        if not hasattr(self.kernel, 'ai_manager'):
            ttk.Label(main_frame, text="AI Manager service is not available.", bootstyle="danger").pack(pady=10)
            return property_vars
        all_providers_raw = self.kernel.ai_manager.get_available_providers()
        provider_display_list = []
        name_to_id_map = {}
        for pid, raw_name in all_providers_raw.items():
            display_name = self.loc.get(raw_name, fallback=pid)
            provider_display_list.append(display_name)
            name_to_id_map[display_name] = pid
        mapping_data = config.get('provider_mapping', {})
        for category in self.TASK_CATEGORIES:
            provider_var = StringVar()
            saved_provider_id = mapping_data.get(category)
            if saved_provider_id:
                for name, pid in name_to_id_map.items():
                    if pid == saved_provider_id:
                        provider_var.set(name)
                        break
            LabelledCombobox(parent=main_frame, label_text=f"{category.replace('_', ' ').title()}:", variable=provider_var, values=sorted(provider_display_list))
            category_vars[category] = provider_var
        class MappingVar:
            def __init__(self, vars_dict, name_map):
                self.vars_dict = vars_dict
                self.name_map = name_map
            def get(self):
                mapping = {}
                for category, tk_var in self.vars_dict.items():
                    selected_name = tk_var.get()
                    if selected_name:
                        mapping[category] = self.name_map.get(selected_name)
                return mapping
        property_vars['provider_mapping'] = MappingVar(category_vars, name_to_id_map)
        debug_vars = shared_properties.create_debug_and_reliability_ui(parent_frame, config, self.loc)
        property_vars.update(debug_vars)
        return property_vars
    def get_data_preview(self, config: dict):
        """
        TODO: Implement the data preview logic for this module.
        This method should return a small, representative sample of the data
        that the 'execute' method would produce.
        It should run quickly and have no side effects.
        """
        self.logger(f"'get_data_preview' is not yet implemented for {self.module_id}", 'WARN')
        return [{'status': 'preview not implemented'}]
