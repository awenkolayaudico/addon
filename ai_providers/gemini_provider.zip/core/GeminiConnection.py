#######################################################################
# dev : awenk audico
# EMAIL SAHIDINAOLA@GMAIL.COM
# WEBSITE WWW.TEETAH.ART
# File NAME : C:\Users\User\Desktop\FLOWORK\ai_providers\gemini_provider\core\GeminiConnection.py
# JUMLAH BARIS : 33
#######################################################################

import google.generativeai as genai
class GeminiConnection:
    """Handles the connection and authentication to the Google AI API."""
    def __init__(self, kernel):
        self.kernel = kernel
        self.variable_manager = self.kernel.get_service("variable_manager")
        self.is_configured = False
    def configure(self):
        """
        Configures the genai library with the API key from Variable Manager.
        Returns True on success, False on failure.
        """
        if self.is_configured:
            return True
        api_key = self.variable_manager.get_variable("GEMINI_API_KEY")
        if not api_key:
            self.kernel.write_to_log("GEMINI_API_KEY not found in Variable Manager.", "ERROR")
            return False
        try:
            genai.configure(api_key=api_key)
            self.is_configured = True
            self.kernel.write_to_log("Google AI (Gemini) has been configured successfully.", "SUCCESS")
            return True
        except Exception as e:
            self.kernel.write_to_log(f"Failed to configure Gemini: {e}", "ERROR")
            return False
