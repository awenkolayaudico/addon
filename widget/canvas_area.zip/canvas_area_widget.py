#######################################################################
# dev : awenk audico
# EMAIL SAHIDINAOLA@GMAIL.COM
# WEBSITE WWW.TEETAH.ART
# File NAME : C:\Users\User\Desktop\FLOWORK\widgets\canvas_area\canvas_area_widget.py
# JUMLAH BARIS : 243
#######################################################################

import ttkbootstrap as ttk
from tkinter import messagebox, simpledialog, scrolledtext
import urllib.parse
from flowork_kernel.ui_shell.version_manager_popup import VersionManagerPopup
from flowork_kernel.ui_shell.custom_widgets.tooltip import ToolTip
from flowork_kernel.api_contract import BaseDashboardWidget
from flowork_kernel.ui_shell.canvas_manager import CanvasManager
import json
from widgets.data_canvas_widget.data_canvas_widget import DataCanvasWidget
class CanvasAreaWidget(BaseDashboardWidget):
    TIER = "free"  # ADDED BY SCANNER: Default tier
    """
    Widget that contains the main canvas and ALL its action buttons, including preset management.
    [UPGRADE]: Now includes the Time-Travel Debugger UI with a manual toggle switch.
    [FIXED]: Correctly handles history data structure to prevent AttributeError.
    """
    def __init__(self, parent, coordinator_tab, kernel, widget_id: str):
        super().__init__(parent, coordinator_tab, kernel, widget_id)
        self.parent_tab = coordinator_tab
        self.canvas_manager = None
        self.execution_history = {}
        self.debugger_mode_var = ttk.BooleanVar(value=False)
        self.view_mode_var = ttk.StringVar(value="logic")
        self._create_widgets()
        self.populate_preset_dropdown()
    def _create_widgets(self):
        main_controls_frame = ttk.Frame(self)
        main_controls_frame.pack(side="top", fill='x')
        action_container = ttk.Frame(main_controls_frame)
        action_container.pack(fill='x', pady=(0, 5), padx=5)
        top_action_frame = ttk.Frame(action_container)
        top_action_frame.pack(fill='x')
        ttk.Button(top_action_frame, text=self.loc.get('save_workflow_button'), command=self.parent_tab.action_handler.save_workflow, style='success.TButton').pack(side='left', padx=(0, 5))
        ttk.Button(top_action_frame, text=self.loc.get('load_workflow_button'), command=self.parent_tab.action_handler.load_workflow, style='info.TButton').pack(side='left', padx=(0, 5))
        ttk.Button(top_action_frame, text=self.loc.get('clear_canvas_button'), command=self.parent_tab.action_handler.clear_canvas, style='danger.TButton').pack(side='left', padx=5)
        view_toggle_frame = ttk.Frame(top_action_frame)
        view_toggle_frame.pack(side='left', padx=25)
        logic_rb = ttk.Radiobutton(view_toggle_frame, text="Tampilan Logika", variable=self.view_mode_var, value="logic", command=self._on_view_mode_change, bootstyle="primary-outline-toolbutton")
        logic_rb.pack(side='left')
        data_rb = ttk.Radiobutton(view_toggle_frame, text="Tampilan Data", variable=self.view_mode_var, value="data", command=self._on_view_mode_change, bootstyle="primary-outline-toolbutton")
        data_rb.pack(side='left')
        ToolTip(logic_rb).update_text("Show the standard workflow logic canvas.")
        ToolTip(data_rb).update_text("Show the live data preview canvas.")
        zoom_frame = ttk.Frame(top_action_frame)
        zoom_frame.pack(side='left', padx=15)
        self.zoom_label = ttk.Label(zoom_frame, text="100%", width=5, anchor='center')
        zoom_in_button = ttk.Button(zoom_frame, text="+", width=2, style='secondary.TButton')
        zoom_out_button = ttk.Button(zoom_frame, text="-", width=2, style='secondary.TButton')
        reset_zoom_button = ttk.Button(zoom_frame, text="⟲", width=2, style='secondary.TButton')
        zoom_in_button.pack(side='left')
        self.zoom_label.pack(side='left', padx=5)
        zoom_out_button.pack(side='left')
        reset_zoom_button.pack(side='left', padx=(5,0))
        ToolTip(zoom_in_button).update_text(self.loc.get('tooltip_zoom_in', fallback="Perbesar"))
        ToolTip(zoom_out_button).update_text(self.loc.get('tooltip_zoom_out', fallback="Perkecil"))
        ToolTip(reset_zoom_button).update_text(self.loc.get('tooltip_zoom_reset', fallback="Reset Zoom"))
        execution_frame = ttk.Frame(top_action_frame)
        execution_frame.pack(side='left', padx=20)
        self.simulate_button = ttk.Button(execution_frame, text=self.loc.get('simulate_workflow_button', fallback="Jalankan Simulasi"), command=self.parent_tab.action_handler.simulate_workflow, style='primary.TButton')
        self.simulate_button.pack(side='left', expand=True, fill='x', padx=(0,5))
        self.run_button = ttk.Button(execution_frame, text=self.loc.get('run_workflow_button'), command=self.parent_tab.action_handler.run_workflow, style='warning.TButton')
        self.run_button.pack(side='left', expand=True, fill='x', padx=(0,5))
        self.pause_resume_button = ttk.Button(execution_frame, text="Jeda", command=self.parent_tab.action_handler.pause_workflow, style='info.TButton', state='disabled')
        self.pause_resume_button.pack(side='left', expand=True, fill='x', padx=(0,5))
        debugger_toggle_frame = ttk.Frame(top_action_frame)
        debugger_toggle_frame.pack(side='left', padx=20)
        debugger_switch = ttk.Checkbutton(debugger_toggle_frame, text="Debugger", variable=self.debugger_mode_var, bootstyle="info-round-toggle", command=self._toggle_debugger_mode)
        debugger_switch.pack(side='left')
        ToolTip(debugger_switch).update_text("Show/Hide the Time-Travel Debugger panel")
        preset_action_frame = ttk.Frame(action_container)
        preset_action_frame.pack(fill='x', pady=(5,0))
        self.manage_versions_button = ttk.Button(preset_action_frame, text=self.loc.get('manage_versions_button', fallback="Kelola Versi"), command=self._open_version_manager, style='info.TButton')
        self.manage_versions_button.pack(side='left', padx=(0, 10))
        ttk.Label(preset_action_frame, text=self.loc.get('load_preset_label')).pack(side='left')
        self.preset_combobox = ttk.Combobox(preset_action_frame, state="readonly", width=30)
        self.preset_combobox.pack(side='left', fill='x', expand=True, padx=10)
        self.preset_combobox.bind("<<ComboboxSelected>>", self._on_preset_selected)
        self.delete_preset_button = ttk.Button(preset_action_frame, text=self.loc.get('delete_preset_button', fallback="Hapus Preset"), command=self._delete_selected_preset, style='danger.TButton')
        self.delete_preset_button.pack(side='left', padx=(0, 5))
        self.save_preset_button = ttk.Button(preset_action_frame, text=self.loc.get('save_preset_button'), command=self._save_as_preset, style='primary.TButton')
        self.save_preset_button.pack(side='left')
        self.webhook_info_frame = ttk.Frame(action_container)
        self.webhook_info_frame.pack(fill='x', expand=True, pady=(5,0))
        ttk.Label(self.webhook_info_frame, text="URL Pemicu:", style='Webhook.TLabel').pack(side='left', padx=(0, 5))
        self.webhook_url_var = ttk.StringVar()
        webhook_url_entry = ttk.Entry(self.webhook_info_frame, textvariable=self.webhook_url_var, state="readonly", width=60, style='Webhook.TEntry')
        webhook_url_entry.pack(side='left', fill='x', expand=True)
        copy_url_button = ttk.Button(self.webhook_info_frame, text="Salin", command=self._copy_webhook_url, style='secondary.TButton')
        copy_url_button.pack(side='left', padx=5)
        self._create_debugger_widgets()
        theme_manager = self.kernel.get_service("theme_manager")
        colors = theme_manager.get_colors() if theme_manager else {'bg': '#222'}
        self.canvas_container = ttk.Frame(self)
        self.canvas_container.pack(expand=True, fill='both')
        self.logic_canvas_frame = ttk.Frame(self.canvas_container)
        self.data_canvas_frame = ttk.Frame(self.canvas_container)
        self.canvas = ttk.Canvas(self.logic_canvas_frame, background=colors.get('bg', '#222'))
        self.canvas.pack(expand=True, fill='both')
        self.canvas_manager = CanvasManager(self, self.parent_tab, self.canvas, self.kernel)
        self.data_canvas_widget = DataCanvasWidget(self.data_canvas_frame, self.parent_tab, self.kernel, "data_canvas_main")
        self.data_canvas_widget.pack(expand=True, fill='both')
        self._on_view_mode_change()
        zoom_in_button.config(command=self.canvas_manager.interaction_manager.navigation_handler.zoom_in)
        zoom_out_button.config(command=self.canvas_manager.interaction_manager.navigation_handler.zoom_out)
        reset_zoom_button.config(command=self.canvas_manager.interaction_manager.navigation_handler.reset_zoom)
    def _on_view_mode_change(self):
        if self.view_mode_var.get() == "data":
            if self.canvas_manager:
                self.data_canvas_widget.sync_with_logic_canvas(self.canvas_manager.canvas_nodes)
            self.logic_canvas_frame.pack_forget()
            self.data_canvas_frame.pack(expand=True, fill='both')
        else: # "logic"
            self.data_canvas_frame.pack_forget()
            self.logic_canvas_frame.pack(expand=True, fill='both')
    def _create_debugger_widgets(self):
        self.debugger_frame = ttk.LabelFrame(self, text=" Mesin Waktu Debugger", padding=5)
        controls_frame = ttk.Frame(self.debugger_frame)
        controls_frame.pack(side="left", fill="y", padx=5)
        self.step_label_var = ttk.StringVar(value="Step: 0/0")
        ttk.Label(controls_frame, textvariable=self.step_label_var).pack(pady=2)
        self.timeline_slider = ttk.Scale(controls_frame, from_=0, to=0, orient="vertical", command=self._on_timeline_scrub)
        self.timeline_slider.pack(fill="y", expand=True, pady=5)
        self.timeline_slider.config(state="disabled")
        close_button = ttk.Button(controls_frame, text="Tutup Debugger", command=self.hide_debugger, bootstyle="secondary-outline")
        close_button.pack(pady=5)
        payload_frame = ttk.LabelFrame(self.debugger_frame, text="Payload di Langkah Terpilih")
        payload_frame.pack(side="left", fill="both", expand=True, padx=5, pady=5)
        self.payload_viewer = scrolledtext.ScrolledText(payload_frame, wrap="word", font=("Consolas", 9))
        self.payload_viewer.pack(fill="both", expand=True)
        self.payload_viewer.config(state="disabled")
    def _toggle_debugger_mode(self):
        if self.debugger_mode_var.get():
            self.show_debugger(self.execution_history or {})
        else:
            self.hide_debugger()
    def show_debugger(self, history_data):
        steps = history_data.get('steps', [])
        self.debugger_frame.pack(side="bottom", fill="x", expand=False, pady=10, padx=5)
        self.debugger_mode_var.set(True)
        if not steps:
            self.kernel.write_to_log("No execution history to debug.", "INFO")
            self.step_label_var.set("Step: 0/0")
            self.timeline_slider.config(to=0, state="disabled")
            self.payload_viewer.config(state="normal")
            self.payload_viewer.delete("1.0", "end")
            self.payload_viewer.insert("1.0", "Run a workflow to generate debug data.")
            self.payload_viewer.config(state="disabled")
            return
        num_steps = len(steps)
        self.timeline_slider.config(to=num_steps - 1, state="normal")
        self.timeline_slider.set(num_steps - 1)
        self._on_timeline_scrub(num_steps - 1)
    def hide_debugger(self):
        self.debugger_frame.pack_forget()
        self.debugger_mode_var.set(False)
        if self.canvas_manager:
            self.canvas_manager.visual_manager.clear_timeline_highlight()
    def _on_timeline_scrub(self, value):
        step_index = int(float(value))
        steps = self.execution_history.get('steps', [])
        if not steps or step_index >= len(steps):
            self.step_label_var.set("Step: 0/0")
            self.payload_viewer.config(state="normal")
            self.payload_viewer.delete("1.0", "end")
            self.payload_viewer.config(state="disabled")
            if self.canvas_manager:
                self.canvas_manager.visual_manager.clear_timeline_highlight()
            return
        current_step = steps[step_index]
        connection_id = current_step.get('connection_id')
        payload = current_step.get('payload', {})
        self.step_label_var.set(f"Step: {step_index + 1}/{len(steps)}")
        self.payload_viewer.config(state="normal")
        self.payload_viewer.delete("1.0", "end")
        try:
            pretty_payload = json.dumps(payload, indent=4, ensure_ascii=False)
            self.payload_viewer.insert("1.0", pretty_payload)
        except Exception as e:
            self.payload_viewer.insert("1.0", f"Error displaying payload: {e}\n\n{payload}")
        self.payload_viewer.config(state="disabled")
        if self.canvas_manager:
            self.canvas_manager.visual_manager.highlight_timeline_step(connection_id)
    def populate_preset_dropdown(self):
        try:
            preset_manager = self.kernel.get_service("preset_manager")
            if not preset_manager: return
            presets = preset_manager.get_preset_list()
            self.preset_combobox['values'] = sorted(presets)
            current_selection = self.preset_combobox.get()
            if current_selection not in presets:
                self.preset_combobox.set('')
        except Exception as e:
            self.kernel.write_to_log(f"Failed to load preset list: {e}", "ERROR")
            self.preset_combobox['values'] = []
        self._update_webhook_info()
    def _update_webhook_info(self):
        loc = self.kernel.get_service("localization_manager")
        api_service = self.kernel.get_service("api_server_service")
        is_webhook_enabled = loc.get_setting('webhook_enabled', False) if loc else False
        selected_preset = self.preset_combobox.get()
        if is_webhook_enabled and selected_preset and api_service:
            host = getattr(api_service, 'host', '127.0.0.1')
            if host == '0.0.0.0': host = '127.0.0.1'
            port = getattr(api_service, 'port', 8989)
            encoded_preset = urllib.parse.quote(selected_preset)
            url = f"http://{host}:{port}/webhook/{encoded_preset}"
            self.webhook_url_var.set(url)
            self.webhook_info_frame.pack(fill='x', pady=(5,0))
        else:
            self.webhook_info_frame.pack_forget()
    def _copy_webhook_url(self):
        url_to_copy = self.webhook_url_var.get()
        if url_to_copy:
            self.clipboard_clear()
            self.clipboard_append(url_to_copy)
            self.kernel.write_to_log(f"URL Webhook disalin ke clipboard: {url_to_copy}", "SUCCESS")
    def _on_preset_selected(self, event=None):
        if hasattr(self.parent_tab, 'action_handler'):
            self.parent_tab.action_handler.on_preset_selected(event)
    def _save_as_preset(self):
        if hasattr(self.parent_tab, 'action_handler'):
            self.parent_tab.action_handler.save_as_preset()
    def _delete_selected_preset(self):
        if hasattr(self.parent_tab, 'action_handler'):
            self.parent_tab.action_handler._delete_selected_preset()
    def _open_version_manager(self):
        selected_preset = self.preset_combobox.get()
        if not selected_preset:
            messagebox.showwarning(self.loc.get('warning_title'), self.loc.get('select_preset_to_delete_warning', fallback="Pilih preset terlebih dahulu untuk mengelola versinya."))
            return
        VersionManagerPopup(self.parent_tab, self.kernel, selected_preset)
    def update_zoom_label(self):
        if hasattr(self, 'zoom_label') and self.canvas_manager and self.canvas_manager.interaction_manager and self.canvas_manager.interaction_manager.navigation_handler:
            self.zoom_label.config(text=f"{int(self.canvas_manager.interaction_manager.navigation_handler.zoom_level * 100)}%")
    def apply_styles(self, colors):
        pass
